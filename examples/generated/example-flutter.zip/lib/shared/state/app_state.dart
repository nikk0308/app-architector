class AppState {
  String currentRoute = '/';
}
